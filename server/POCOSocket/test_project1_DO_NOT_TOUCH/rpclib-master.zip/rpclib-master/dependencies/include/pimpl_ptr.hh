#ifndef PIMPL_PTR_HH_
#define PIMPL_PTR_HH_


#endif /* PIMPL_PTR_HH_ */
